import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;

import java.io.File;
import java.io.IOException;

public class PDFTextExtractor {
    
    String filePath = "path/to/file.pdf";
    
    public String extractTextFromPDF(String filePath) throws IOException {
        PDDocument document = null;
        try {
            document = PDDocument.load(new File(filePath));
            PDFTextStripper stripper = new PDFTextStripper();
            System.out.println("Extracted Text:\n" + stripper.getText(document));
            return stripper.getText(document);
        } finally {
            if (document != null) {
                document.close();
            }
        }
       
    }
}
