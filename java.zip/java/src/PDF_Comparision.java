/**
 * Run the following Commands after making changes to the code
 * Step #1 : javac -d classes src/name/fraser/neil/plaintext/diff_match_patch.java src/Diffhtml.java
 * Step #2 : java -classpath classes Diffhtml
 * 
 */


import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import name.fraser.neil.plaintext.diff_match_patch;
import name.fraser.neil.plaintext.diff_match_patch.Diff;
import name.fraser.neil.plaintext.diff_match_patch.Operation;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;


public class PDF_Comparision {
  public static void main(String args[]) throws IOException {
    
    File htmlTemplateFile = new File("template.html");
    String title = " PDFs difference report";
    String heading = "*** Here are the Differences between the pdfs ***";
    File newHtmlFile = new File("PDF_Diff_Report.html");
    String pdf1 = "pdf1.pdf";
    String pdf2 = "pdf2.pdf";
    
    diff_match_patch dmp = new diff_match_patch();
    String pdf_content_1 = new PDFTextExtractor().extractTextFromPDF(pdf1);
    String pdf_content_2 = new PDFTextExtractor().extractTextFromPDF(pdf2);
    
    //String pdffileContent_1 = "Hello World."; // Content from PDF File_1
    //String pdffileContent_2 = "Goodbye World."; // Content from PDF File_2
    
    LinkedList<diff_match_patch.Diff> diff = dmp.diff_main(pdf_content_1,pdf_content_2 );
    dmp.diff_cleanupSemantic(diff);
    System.out.println(diff);


    String htmlString = FileUtils.readFileToString(htmlTemplateFile);

    String body = convertToHTMLString(diff);
    htmlString = htmlString.replace("$title", title);
    htmlString = htmlString.replace("$heading", heading);
    htmlString = htmlString.replace("$pdf1", pdf1);
    htmlString = htmlString.replace("$pdf2", pdf2);
    htmlString = htmlString.replace("$body", body );

    FileUtils.writeStringToFile(newHtmlFile, htmlString);

  }


  public static String convertToHTMLString(LinkedList<Diff> diff) {

      List<String> html = new ArrayList<String>();
      String pattern_amp = "/&/g";
      String pattern_lt = "/</g";
      String pattern_gt = "/>/g";
      String pattern_para = "/\n/g";
      for (int x = 0; x < diff.size(); x++) {
        Operation op = diff.get(x).operation;    // Operation (insert, delete, equal)
        String data = diff.get(x).text;  // Text of change.
        String text = data.replace(pattern_amp, "&amp;").replace(pattern_lt, "&lt;")
            .replace(pattern_gt, "&gt;").replace(pattern_para, "&para;<br>");
        switch (op) {
          case INSERT:
          html.add("<ins style=\"background:#e6ffe6;\">" + text + "</ins>");
            break;
          case DELETE:
            html.add("<del style=\"background:#ffe6e6;\">" + text + "</del>");
            break;
          case EQUAL:
            html.add("<span>" + text + "</span>");
            break;
        }
      }
      return String.join(" ",html);
    }


}